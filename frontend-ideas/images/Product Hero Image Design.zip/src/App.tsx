import { useState } from "react";

const images = {
  hero: "https://images.unsplash.com/photo-1771073387047-df16b4889412?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=88&w=1600",
  cabinet: "https://images.unsplash.com/photo-1688973120381-a916124254e8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=84&w=1000",
  statue: "https://images.unsplash.com/photo-1604864708171-b6a408b4cba2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=84&w=1000",
  archive: "https://images.unsplash.com/photo-1784811909735-8f85ccc1d381?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=84&w=1000",
  urn: "https://images.unsplash.com/photo-1769981533227-2bbf02c714f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixlib=rb-4.1.0&q=84&w=1200",
};

function Icon({
  name,
  className = "h-5 w-5",
}: {
  name: "arrow" | "search" | "user" | "heart" | "menu" | "clock";
  className?: string;
}) {
  const paths = {
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    search: <><circle cx="11" cy="11" r="6.5" /><path d="m16 16 4 4" /></>,
    user: <><circle cx="12" cy="8" r="3.5" /><path d="M5.5 20c.7-4 2.8-6 6.5-6s5.8 2 6.5 6" /></>,
    heart: <path d="M20.8 8.6c0 5-8.8 10.4-8.8 10.4S3.2 13.6 3.2 8.6A4.6 4.6 0 0 1 12 6.7a4.6 4.6 0 0 1 8.8 1.9Z" />,
    menu: <><path d="M4 8h16M4 16h16" /></>,
    clock: <><circle cx="12" cy="12" r="8.5" /><path d="M12 7v5l3 2" /></>,
  };
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className={className}>
      {paths[name]}
    </svg>
  );
}

const lots = [
  { image: images.cabinet, label: "Decorative Arts", title: "Arts & Crafts dining suite", bid: "$4,200", time: "02h 14m", position: "object-center" },
  { image: images.statue, label: "Sculpture", title: "Marble figure of Venus", bid: "$2,850", time: "04h 38m", position: "object-center" },
  { image: images.archive, label: "Collectibles", title: "The grand tour archive", bid: "$1,475", time: "06h 02m", position: "object-center" },
];

function LotCard({ lot, index }: { lot: (typeof lots)[number]; index: number }) {
  const [saved, setSaved] = useState(false);
  return (
    <article className="group">
      <div className="relative aspect-[4/5] overflow-hidden bg-[#ded8cc]">
        <img src={lot.image} alt={lot.title} className={`h-full w-full ${lot.position} object-cover transition-transform duration-700 group-hover:scale-[1.035]`} />
        <div className="absolute inset-x-0 top-0 flex items-center justify-between p-4">
          <span className="bg-[#f3efe6]/95 px-3 py-2 text-[0.58rem] font-semibold uppercase tracking-[0.16em] backdrop-blur-sm">
            Lot {String(index + 18).padStart(3, "0")}
          </span>
          <button onClick={() => setSaved(!saved)} aria-label={saved ? "Remove from saved lots" : "Save lot"} className={`flex h-10 w-10 items-center justify-center rounded-full backdrop-blur-md transition-colors ${saved ? "bg-[#8d3228] text-white" : "bg-[#f3efe6]/90 hover:bg-white"}`}>
            <Icon name="heart" className={`h-4 w-4 ${saved ? "fill-current" : ""}`} />
          </button>
        </div>
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-black/55 to-transparent" />
        <div className="absolute bottom-4 left-4 flex items-center gap-2 text-[0.61rem] font-semibold uppercase tracking-[0.12em] text-white">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#dc8b69]" /> Live auction
        </div>
      </div>
      <div className="border-b border-[#24251f]/20 pb-6 pt-5">
        <p className="text-[0.6rem] font-semibold uppercase tracking-[0.18em] text-[#8d3228]">{lot.label}</p>
        <h3 className="font-display mt-2 text-[1.7rem] leading-tight">{lot.title}</h3>
        <div className="mt-5 flex items-end justify-between">
          <div>
            <p className="text-[0.57rem] uppercase tracking-[0.14em] text-black/45">Current bid</p>
            <p className="mt-1 font-medium">{lot.bid}</p>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-black/55"><Icon name="clock" className="h-3.5 w-3.5" /> {lot.time}</div>
        </div>
      </div>
    </article>
  );
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  return (
    <main className="min-h-screen overflow-hidden bg-[#f3efe6] text-[#20211d]">
      <div className="bg-[#20211d] px-5 py-2.5 text-center text-[0.59rem] font-medium uppercase tracking-[0.18em] text-white sm:text-[0.65rem]">
        Complimentary valuations for new consignments <span className="ml-2 border-b border-white/50 pb-0.5">Learn more</span>
      </div>

      <header className="relative z-40 border-b border-black/10 bg-[#f3efe6]">
        <div className="mx-auto flex h-[76px] max-w-[1440px] items-center justify-between px-5 md:px-9 lg:px-12">
          <a href="#" className="flex items-center gap-3">
            <span className="flex h-8 w-8 rotate-45 items-center justify-center border border-[#8d3228]"><span className="-rotate-45 font-display text-base text-[#8d3228]">A</span></span>
            <span className="font-display text-[1.55rem] tracking-[0.04em]">AURELIA</span>
          </a>
          <nav className="hidden items-center gap-8 text-[0.66rem] font-semibold uppercase tracking-[0.15em] lg:flex">
            <a href="#auctions" className="hover:text-[#8d3228]">Auctions</a>
            <a href="#categories" className="hover:text-[#8d3228]">Departments</a>
            <a href="#sell" className="hover:text-[#8d3228]">Sell with us</a>
            <a href="#stories" className="hover:text-[#8d3228]">Stories</a>
          </nav>
          <div className="flex items-center gap-1 sm:gap-2">
            <button onClick={() => setSearchOpen(!searchOpen)} aria-label="Search" className="flex h-10 w-10 items-center justify-center hover:text-[#8d3228]"><Icon name="search" className="h-[18px] w-[18px]" /></button>
            <button aria-label="Account" className="hidden h-10 w-10 items-center justify-center hover:text-[#8d3228] sm:flex"><Icon name="user" className="h-[18px] w-[18px]" /></button>
            <a href="#sell" className="ml-1 hidden bg-[#8d3228] px-5 py-3 text-[0.62rem] font-semibold uppercase tracking-[0.14em] text-white transition-colors hover:bg-[#70261f] sm:block">Sell an item</a>
            <button onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu" className="ml-1 flex h-10 w-10 items-center justify-center lg:hidden"><Icon name="menu" /></button>
          </div>
        </div>
        {searchOpen && (
          <div className="absolute inset-x-0 top-full border-y border-black/10 bg-[#f3efe6] p-4 shadow-xl">
            <div className="mx-auto flex max-w-3xl items-center gap-3 border-b border-black/30 py-2">
              <Icon name="search" /><input autoFocus aria-label="Search auctions" placeholder="Search artists, makers, objects..." className="w-full bg-transparent py-2 text-lg outline-none placeholder:text-black/35" />
            </div>
          </div>
        )}
        {menuOpen && (
          <nav className="absolute inset-x-0 top-full flex flex-col border-b border-black/10 bg-[#f3efe6] px-6 py-6 text-sm font-semibold uppercase tracking-[0.14em] shadow-xl lg:hidden">
            {["Auctions", "Departments", "Sell with us", "Stories"].map((item) => <a key={item} href={`#${item.toLowerCase().split(" ")[0]}`} onClick={() => setMenuOpen(false)} className="border-b border-black/10 py-4">{item}</a>)}
          </nav>
        )}
      </header>

      <section className="relative mx-auto grid min-h-[700px] max-w-[1440px] lg:grid-cols-[48%_52%]">
        <div className="relative z-10 flex flex-col justify-center px-6 py-20 md:px-12 lg:px-16 lg:py-24">
          <p className="mb-7 flex items-center gap-3 text-[0.63rem] font-semibold uppercase tracking-[0.22em] text-[#8d3228]"><span className="h-px w-10 bg-[#8d3228]" /> Objects of consequence</p>
          <h1 className="font-display max-w-[650px] text-[clamp(4.4rem,8.2vw,8.4rem)] leading-[0.79] tracking-[-0.045em]">
            History,<br /><span className="italic text-[#8d3228]">within reach.</span>
          </h1>
          <p className="mt-8 max-w-md text-sm leading-7 text-black/58 md:text-base">
            Discover remarkable antiques, fine art and singular objects, sourced by specialists and offered to collectors worldwide.
          </p>
          <div className="mt-9 flex flex-wrap gap-3">
            <a href="#auctions" className="group flex items-center gap-10 bg-[#20211d] px-6 py-4 text-[0.65rem] font-semibold uppercase tracking-[0.15em] text-white transition-colors hover:bg-[#8d3228]">Explore auctions <Icon name="arrow" className="h-4 w-4 transition-transform group-hover:translate-x-1" /></a>
            <a href="#sell" className="border border-black/25 px-6 py-4 text-[0.65rem] font-semibold uppercase tracking-[0.15em] hover:border-black">Request a valuation</a>
          </div>
          <div className="mt-16 grid max-w-md grid-cols-2 border-t border-black/15 pt-5">
            <div><p className="font-display text-2xl">2,418</p><p className="mt-1 text-[0.55rem] uppercase tracking-[0.16em] text-black/45">Lots available</p></div>
            <div><p className="font-display text-2xl">36</p><p className="mt-1 text-[0.55rem] uppercase tracking-[0.16em] text-black/45">Auctions this month</p></div>
          </div>
        </div>
        <div className="relative min-h-[600px] overflow-hidden lg:min-h-full">
          <img src={images.hero} alt="Ornate antique vase with gold detailing" className="absolute inset-0 h-full w-full object-cover object-center" />
          <div className="absolute inset-0 bg-[linear-gradient(180deg,rgba(18,18,15,0.08),rgba(18,18,15,0.1)_55%,rgba(18,18,15,0.72))]" />
          <div className="absolute right-5 top-5 flex items-center gap-2 border border-white/35 bg-black/10 px-4 py-2 text-[0.58rem] font-semibold uppercase tracking-[0.17em] text-white backdrop-blur-md md:right-8 md:top-8"><span className="h-1.5 w-1.5 rounded-full bg-[#e6a287]" /> Featured lot</div>
          <div className="absolute bottom-0 left-0 right-0 p-6 text-white md:p-10 lg:p-12">
            <p className="text-[0.6rem] font-semibold uppercase tracking-[0.19em] text-white/65">European Decorative Arts · Lot 104</p>
            <div className="mt-3 flex items-end justify-between gap-5">
              <div><h2 className="font-display text-3xl md:text-4xl">Empire porcelain urn</h2><p className="mt-2 text-xs text-white/65">Vienna, circa 1820</p></div>
              <a href="#auctions" aria-label="View featured lot" className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-[#f3efe6] text-black transition-transform hover:rotate-[-15deg]"><Icon name="arrow" /></a>
            </div>
          </div>
        </div>
      </section>

      <section id="auctions" className="border-t border-black/10 px-6 py-24 md:px-10 lg:px-12 lg:py-32">
        <div className="mx-auto max-w-[1344px]">
          <div className="mb-12 flex items-end justify-between gap-8">
            <div><p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-[#8d3228]">Closing soon</p><h2 className="font-display mt-3 text-4xl md:text-6xl">Live auctions</h2></div>
            <a href="#" className="group hidden items-center gap-6 border-b border-black pb-2 text-[0.63rem] font-semibold uppercase tracking-[0.14em] sm:flex">View all lots <Icon name="arrow" className="h-4 w-4 transition-transform group-hover:translate-x-1" /></a>
          </div>
          <div className="grid gap-10 md:grid-cols-3 md:gap-5 lg:gap-8">{lots.map((lot, index) => <LotCard key={lot.title} lot={lot} index={index} />)}</div>
        </div>
      </section>

      <section id="categories" className="bg-[#20211d] px-6 py-24 text-[#f3efe6] md:px-10 lg:px-12 lg:py-32">
        <div className="mx-auto grid max-w-[1344px] gap-14 lg:grid-cols-[42%_58%]">
          <div className="lg:pr-16"><p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em] text-[#d78d72]">Curated expertise</p><h2 className="font-display mt-4 text-5xl leading-[0.95] md:text-7xl">Find what<br /><span className="italic text-[#d78d72]">moves you.</span></h2><p className="mt-7 max-w-sm text-sm leading-7 text-white/55">From ancient artefacts to modern design, our specialists bring knowledge, context and confidence to every acquisition.</p></div>
          <div className="border-t border-white/20">
            {["Fine art", "Decorative arts", "Jewellery & watches", "Books & manuscripts", "Asian art"].map((category, index) => (
              <a href="#auctions" key={category} className="group flex items-center justify-between border-b border-white/20 py-5 md:py-6">
                <div className="flex items-center gap-5"><span className="text-[0.55rem] text-white/35">0{index + 1}</span><span className="font-display text-2xl transition-transform group-hover:translate-x-2 md:text-3xl">{category}</span></div>
                <Icon name="arrow" className="h-5 w-5 text-white/45 transition-all group-hover:translate-x-1 group-hover:text-white" />
              </a>
            ))}
          </div>
        </div>
      </section>

      <section id="sell" className="grid lg:grid-cols-2">
        <div className="relative min-h-[500px]"><img src={images.urn} alt="Antique urn silhouetted by soft window light" className="absolute inset-0 h-full w-full object-cover" /></div>
        <div className="flex items-center bg-[#b6a879] px-7 py-20 md:px-14 lg:px-20 lg:py-28">
          <div className="max-w-xl"><p className="text-[0.62rem] font-semibold uppercase tracking-[0.2em]">Sell with Aurelia</p><h2 className="font-display mt-5 text-5xl leading-[0.95] md:text-7xl">Every object has <span className="italic text-[#742a23]">a story.</span></h2><p className="mt-7 max-w-md text-sm leading-7 text-black/65">Our specialists make selling simple. Begin with a complimentary, confidential valuation and discover what your piece could achieve.</p><a href="#" className="group mt-9 flex w-max items-center gap-10 bg-[#20211d] px-6 py-4 text-[0.65rem] font-semibold uppercase tracking-[0.15em] text-white">Start your valuation <Icon name="arrow" className="h-4 w-4 transition-transform group-hover:translate-x-1" /></a></div>
        </div>
      </section>

      <footer className="bg-[#171814] px-6 pb-8 pt-16 text-white md:px-10 lg:px-12">
        <div className="mx-auto max-w-[1344px]">
          <div className="grid gap-12 border-b border-white/15 pb-14 md:grid-cols-[2fr_1fr_1fr]">
            <div><p className="font-display text-3xl tracking-[0.04em]">AURELIA</p><p className="mt-4 max-w-xs text-xs leading-6 text-white/45">Exceptional objects. Expertly found.<br />London · Paris · New York</p></div>
            <div><p className="text-[0.58rem] uppercase tracking-[0.18em] text-white/35">Explore</p><div className="mt-5 flex flex-col gap-3 text-sm"><a href="#auctions">Auctions</a><a href="#categories">Departments</a><a href="#sell">Sell with us</a></div></div>
            <div><p className="text-[0.58rem] uppercase tracking-[0.18em] text-white/35">Stay informed</p><p className="mt-5 text-xs text-white/55">Stories, auctions and remarkable finds.</p><div className="mt-4 flex border-b border-white/30 pb-2"><input aria-label="Email address" className="w-full bg-transparent text-sm outline-none placeholder:text-white/30" placeholder="Email address" /><Icon name="arrow" className="h-4 w-4" /></div></div>
          </div>
          <div className="flex flex-col gap-3 pt-7 text-[0.55rem] uppercase tracking-[0.12em] text-white/35 sm:flex-row sm:justify-between"><p>© 2025 Aurelia Auction House</p><p>Terms · Privacy · Accessibility</p></div>
        </div>
      </footer>
    </main>
  );
}
